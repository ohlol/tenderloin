from collections import defaultdict

plugin_data = []
